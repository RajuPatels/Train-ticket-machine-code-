﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainTicketApi.Data.Models;
using TrainTicketApi.Data.Service.Abstract;

namespace TrainTicketApi.Data.Service.Derived
{
    public class TicketStationService : IStationService
    {

        #region
        //getallstartedwithname declare with first charectar in the word.
        public string GetAllStartedWithName(string input)
        {
            try
            {
                string[] arraystations = GetAllStations();
                List<SearchStationResult> searchResultList = new List<SearchStationResult>();
                for (int i = 0; i < StationsArray.stations.Length; i++)
                {
                    if (arraystations[i].StartsWith(input))
                    {
                        searchResultList.Add(new SearchStationResult
                        {
                            station = arraystations[i],
                            nextCharacter = GetNextCharacter(arraystations[i], input)
                        });
                    }
                }
                string stations = "A. The  arrving stations ";


                string characters = "B.The  next characters  in the word  ";

                if (searchResultList.Count == 0)
                {
                    stations = "A.no next characters ";


                    characters = "B.no stations";
                }
                else
                {
                    foreach (var item in searchResultList)
                    {
                        stations += item.station + " ";
                        characters += item.nextCharacter + " ";


                    }
                }

                return stations + characters;
            }
            catch
            {
                return null;
            }
            
            
        }
        #endregion


        #region
        // delcare an array Getallstations with getallstation details 
        public string[] GetAllStations()
        {
            
            return StationsArray.stations = new string[] { "DARTFORD", "DARTMOUTH",  "LIVERPOOL", "LIVERPOOL LIME STREET", "DERBY", "TOWER HILL", "PADDINGTON", "EUSTON", "LONDON BRIDGE", "VICTORIA"  };
        }
        #endregion 
        #region

        //declare getnextcharcter shows moving the next character .
        public char GetNextCharacter(string reference, string input)
        {
            try
            {
                return reference.Replace(input, String.Empty).ToCharArray().ToList()[0];
            }

            catch
            {
                return (char)0;
            }
        }
        #endregion 
    }
}
