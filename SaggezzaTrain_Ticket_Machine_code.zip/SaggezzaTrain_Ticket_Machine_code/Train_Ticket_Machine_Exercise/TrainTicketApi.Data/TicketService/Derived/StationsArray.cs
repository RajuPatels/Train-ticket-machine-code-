﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrainTicketApi.Data.Service.Derived
{
    #region
    public static class StationsArray
    {
        public static string[] stations { get; set; }
        
    }
    #endregion
}
