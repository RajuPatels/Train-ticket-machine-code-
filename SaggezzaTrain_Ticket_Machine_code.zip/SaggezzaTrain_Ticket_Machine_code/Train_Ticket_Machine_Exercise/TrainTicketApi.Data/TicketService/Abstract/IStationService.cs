﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainTicketApi.Data.Models;

namespace TrainTicketApi.Data.Service.Abstract
{
    public interface IStationService
    {
        string[] GetAllStations();
       string GetAllStartedWithName(string input);
        char GetNextCharacter(string reference, string input);
    }
}
