﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Train_Ticket_Machine.Business.Abstract;

namespace Train_Ticket_Machine.Controllers
{
    [Route("api/[controller]")]
    [ApiController]


    #region
    public class TicketController : ControllerBase
    {
        private readonly IStationContext _stationContext;
        public TicketController(IStationContext stationContext)
        {
            _stationContext = stationContext;
        }

        //here Getallstartwithname  method withod declare allticket_station serach with one specific character
        [HttpGet("GetAllStartWithName")]
        public IActionResult GetAllStartedWithName(string input)
        {
            var resp = _stationContext.GetAllStartedWithName(input);
            var response = Ok(new { status = 200, success = true, data = resp });
            return response;
        }
        //here Getallstation methos declare allticketstations like(‘DARTFORD’, ‘DARTMOUTH’, ‘TOWER HILL’, ‘DERBY’)
        [HttpGet("GetAllStations")]
        public IActionResult GetAllStations()
        {

            var resp = _stationContext.GetAllStations();
            var response = Ok(new { status = 200, success = true, data = resp });
            return response;
        }
        //here Getnextcharacter method  delcare next character in the word 
        [HttpGet("GetNextCharacter")]
        public IActionResult GetNextCharacter(string reference, string input)
        {
            var resp = _stationContext.GetNextCharacter(reference, input);
            var response = Ok(new { status = 200, success = true, data = resp });
            return response;
        }


    }
    #endregion
}
