﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Train_Ticket_Machine.Business.Abstract;
using TrainTicketApi.Data.Models;
using TrainTicketApi.Data.Service.Abstract;

namespace Train_Ticket_Machine.Business.Derived
{
    #region
    public class StationContext : IStationContext
    {
        private readonly IStationService _service;
        public StationContext(IStationService stationService)
        {
            _service = stationService;
        }
        public string GetAllStartedWithName(string input)
        {
            var resp = _service.GetAllStartedWithName(input);
            return resp;
        }

        public string[] GetAllStations()
        {
            var resp = _service.GetAllStations();
            return resp;
        }

        public char GetNextCharacter(string reference, string input)
        {
            var resp = _service.GetNextCharacter(reference, input);
            return resp;
        }
    }
    #endregion
}
