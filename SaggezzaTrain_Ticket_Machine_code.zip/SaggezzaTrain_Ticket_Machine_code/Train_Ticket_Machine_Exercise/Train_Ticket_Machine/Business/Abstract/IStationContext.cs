﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrainTicketApi.Data.Models;

namespace Train_Ticket_Machine.Business.Abstract
{
    public interface IStationContext
    {
        string[] GetAllStations();
        string GetAllStartedWithName(string input);
        char GetNextCharacter(string reference, string input);
    }
}
